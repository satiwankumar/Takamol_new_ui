import * as React from "react";
import { makeStyles } from "@mui/styles";
import { Button, Container, Divider, Typography } from "@mui/material";
import BoxWrapper from "../../../../components/ui/BoxWrapper";
import { ReactComponent as FileIcon } from "../../../../assets/images/icon.svg";
// import { useTranslation } from "react-i18next";
import { CONVERTSTATUS, E2A } from "../../../../utils/common/utils";
import {  useSelector } from "react-redux";
import { useLocale } from "src/hooks/useLocale/useLocale";

const useStyles = makeStyles(() => ({
  root: {
    // "& .MuiButton-outlined": {
    //   marginRight: theme.spacing(1),
    // },
  },
  btnHeader: {
    marginRight: "10px!important",
    marginLeft: "10px!important",
    borderRadius: "6px!important",
    backgroundColor: "#ECF5F5!important",
    border: "1px solid #148287!important",
    color: "#148287!important",
    padding: "10px 25px!important",
  },
  headingtextmb: {
    marginBottom: "0px!important",
  },
  tpbox: {
    display: "flex",
    justifyContent: "space-between",
  },
  icon: {
    marginBottom: "-12px",
    marginRight: "12px",
    marginLeft: "12px",
  },
  textarea: {
    marginBottom: "20px!important",
    fontFamily: "Frutiger LT Arabic",
    fontSize: "20px!important",
    fontWeight: "700",
    color: "rgba(0, 0, 0, 0.87)",
  },
  textareapp: {
    marginBottom: "20px!important",
    fontFamily: "Frutiger LT Arabic",
    fontSize: "20px!important",
    fontWeight: "700",
    color: "#E31B0C",
  },
  headtextarea: {
    fontFamily: "Frutiger LT Arabic",
    fontSize: "14px!important",
    fontWeight: "400",
    color: "rgba(0, 0, 0, 0.65)",
  },
}));

function CompareAssessmentScoring(props: any) {
  const { t, locale } = useLocale();
  const classes = useStyles();
  const langDir = useSelector((state: any) => state.langDir);

  React.useEffect(() => {}, [props]);

  console.log("props", props);
  return (
    <BoxWrapper>
      <React.Fragment>
        <div className={classes.tpbox}>
          <Typography variant="h5" className={classes.headingtextmb}>
            {" "}
            <FileIcon className={classes.icon} />
            {t("Scoring")}
          </Typography>
        </div>

        <Divider sx={{ mb: 3, mt: 4 }} />
        <Typography variant="body2" className={classes.headtextarea}>
          {t("CRscore")}
        </Typography>
        <Typography color="info" variant="h6" className={classes.textarea}>
          {E2A(String(props.scoring?.score), langDir)}%
        </Typography>

        <Typography variant="body2" className={classes.headtextarea}>
          {t("Auditorscore")}{" "}
        </Typography>
        <Typography color="info" variant="h6" className={classes.textarea}>
          {props.scoring?.verifierComment != null
            ? E2A(String(props.scoring?.verifierScore), langDir) + "%"
            : "-"}
        </Typography>

        <Typography variant="body2" className={classes.headtextarea}>
          {t("DifferencebetweenCRandAuditorscore")}
        </Typography>
        <Typography color="info" variant="h6" className={classes.textareapp}>
          {props.scoring?.verifierComment != null
            ? E2A(
                String(props.scoring?.score - props.scoring?.verifierScore),
                langDir
              ) + "%"
            : "-"}
        </Typography>

        <Typography variant="body2" className={classes.headtextarea}>
          {t("Inspectorscore")}{" "}
        </Typography>
        <Typography color="info" variant="h6" className={classes.textarea}>
          {props?.scoring?.inspectorComment != null
            ? E2A(String(props.scoring?.inspectorScore), langDir) + "%"
            : "-"}
        </Typography>

        <Typography variant="body2" className={classes.headtextarea}>
          {t("DifferencebetweenAuditorandInspectorscore")}
        </Typography>
        <Typography color="info" variant="h6" className={classes.textareapp}>
          {props?.scoring?.inspectorComment != null
            ? E2A(
                String(
                  props.scoring?.verifierScore - props.scoring?.inspectorScore
                ),
                langDir
              ) + "%"
            : "-"}
        </Typography>
        <Typography className={classes.headtextarea} variant="body2">
          {t("SUPERVISORSCORE")}
        </Typography>
        <Typography className={classes.textareapp} color="info" variant="h6">
          {props?.scoring?.supervisorComment != null
            ? E2A(String(props.scoring?.supervisorScore), langDir) + "%"
            : "-"}
        </Typography>
        <Typography className={classes.headtextarea} variant="body2">
          {t("DifferencebetweenAuditorandSupervisorscore")}
        </Typography>
        <Typography className={classes.textareapp} color="info" variant="h6">
          {props?.scoring?.supervisorComment != null
            ? E2A(  
                String(
                  props.scoring?.verifierScore - props.scoring?.supervisorScore
                ),
                langDir
              ) + "%"
            : "-"}
        </Typography>
      </React.Fragment>
    </BoxWrapper>
  );
}

export default CompareAssessmentScoring;
