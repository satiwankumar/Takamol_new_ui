import React, { useEffect, useState } from "react";
import { makeStyles } from "@mui/styles";
import { Button, Container } from "@mui/material";
import { DetailsHeader } from "../../../../components/ui/DetailsHeader";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import CompareAssessmentScoring from "./CompareAssessmentScoring";
import CompareAssessmentComment from "./CompareAssessmentComment";
import CompareAssessmentAnswerSection from "./CompareAssessmentAnswerSection";
import { useHistory, useParams } from "react-router-dom";
import { PCREQUESTSCARD } from "../../../../utils/common/endpoint";
import { GetRequest, PatchRequest } from "../../../../Axios/axios"
import { useSelector } from "react-redux";
import { AcceptRejectSubmitDialog } from "./AcceptRejectSubmitDialog";
import { RejectSubmitDialogBox } from "./RejectSubmitDialogBox";
import ArrowBackwordIcon from "@mui/icons-material/ArrowBack";
import { useLocale } from "src/hooks/useLocale/useLocale";


const useStyles = makeStyles(() => ({
  root: {
    // "& .btnReject": {
    //   marginRight: theme.spacing(1),
    // },
  },
  btnHeader: {
    marginRight: "10px!important",
    marginLeft: "10px!important",
    backgroundColor: "#ECF5F5!important",
    border: "1px solid #148287!important",
    color: "#148287!important",
    padding: "10px 25px!important",
  },
  btnReject: {
    color: "#ff5246!important",
    border: "1px solid #ff5246!important",
    marginRight: "10px!important",
    backgroundColor: "#ECF5F5!important",
    padding: "10px !important",
  },
  btnApprove: {
    padding: "10px !important",
    border: "1px solid #148287!important",
  },
}));

function CompareAssessment() {
  const { t } = useLocale();
  const classes = useStyles();
  const {id} = useParams<any>()
  const [openPublishDialog, setOpenPublishDialog] = useState(false);
  const [openRejectDialog, setOpenRejectDialog] = useState(false);
  const [scoring, setScoring] = useState<any>({});
  const [finalComment, setFinalComment] = useState<any>("");
  const [isVerifier, setIsVerifier] = useState<any>(false);
  const [isInspector, setIsInspector] = useState<any>(false);
  const [isSuperVisor, setIsSuperVisor] = useState<any>(false);

  const [assessmentAnswers, setAssessmentAnswers] = useState<any>([]);
  const user = useSelector((state: any) => state.user);
  const history = useHistory();
  function handlePublish() {
    setOpenPublishDialog(true);
  }

  function handleRejectPublish() {
    setOpenRejectDialog(true);
  }
  async function ApproveRejectPCR(status: any) {
    let obj = {};
    if (status) {
      obj = {
        performanceCardRequestStatus: "Card Issued"
      };
      const url = `${process.env.REACT_APP_BASE_URL}/${PCREQUESTSCARD}/${id}`;
      const result = await PatchRequest(url, obj);
      if (result && result.status === 200) {
        history.push("/pcrequestlist");
      }
    } else {
      obj = {
        performanceCardRequestStatus: "Rejected"
      };
      const url = `${process.env.REACT_APP_BASE_URL}/${PCREQUESTSCARD}/${id}`;
      const result = await PatchRequest(url, obj);
      if (result && result.status === 200) {
        history.push("/pcrequestlist");
      }
    }
  }
  async function getAssesmentData() {
    const url = `${process.env.REACT_APP_BASE_URL}/${PCREQUESTSCARD}/${id}`;
    const result = await GetRequest(url);
    if (result && result.status === 200) {
      let {
        score,
        inspectorScore,
        verifierScore,
        supervisorScore,
        verifierComment,
        inspectorComment,
        supervisorComment,
      } = result.data;
      setScoring({
        score,
        inspectorScore,
        verifierScore,
        supervisorScore,
        verifierComment,
        inspectorComment,
        supervisorComment,
      });
      setAssessmentAnswers(
        result.data.selfAssessmentTemplateSectionQuestionsAnswers
      );
      if (user?.scope?.includes("VERIFIER")) {
        let { verifierComment } = result.data;
        setIsVerifier(true);
        setFinalComment(verifierComment);
      }
      if (user?.scope?.includes("INSPECTOR")) {
        let { inspectorComment } = result.data;
        setIsInspector(true);
        setFinalComment(inspectorComment);
      }
      if (user?.scope?.includes("SUPERVISIOR")) {
        let { supervisorComment } = result.data;
        setIsSuperVisor(true);
        setFinalComment(supervisorComment);
      }
    }
  }
  useEffect(() => {
    getAssesmentData();
  }, []);
  return (
    <Container maxWidth="lg">
      <DetailsHeader
        title={t("CompareAssessments")}
        subtitle={t("Herescoringquestionsanswersattachedevidences")}
      >
        <React.Fragment>
          {isSuperVisor && scoring?.score >= 50 && (
            <Button
              variant="contained"
              className={classes.btnApprove}
              sx={{ ml: 1 }}
              onClick={handleRejectPublish}
            >
              {t("Approve")}
            </Button>
          )}
          {isSuperVisor && (
            <Button
              variant="contained"
              color="secondary"
              className={classes.btnReject}
              onClick={handlePublish}
            >
              {t("Reject")}
            </Button>
          )}
          <Button
            variant="contained"
            color="secondary"
            className={classes.btnHeader}
            onClick={() => history.push(`/pcrequestDetail/${id}`)}
          >
            <ArrowBackwordIcon />
          </Button>
        </React.Fragment>
      </DetailsHeader>
      <CompareAssessmentScoring scoring={scoring}></CompareAssessmentScoring>
      <CompareAssessmentAnswerSection
        isVerifier={isVerifier}
        isInspector={isInspector}
        isSuperVisor={isSuperVisor}
        assessmentAnswers={assessmentAnswers}
      ></CompareAssessmentAnswerSection>
      <CompareAssessmentComment
        finalComment={finalComment}
      ></CompareAssessmentComment>
      <AcceptRejectSubmitDialog
        handleClose={() => {
          setOpenRejectDialog(false);
        }}
        open={openRejectDialog}
        handleSubmit={() => ApproveRejectPCR("Card Issued")}
      />

      <RejectSubmitDialogBox
        handleClose={() => {
          setOpenPublishDialog(false);
        }}
        open={openPublishDialog}
        handleSubmit={() => ApproveRejectPCR("Rejected")}
      />
    </Container>
  );
}

export default CompareAssessment;
